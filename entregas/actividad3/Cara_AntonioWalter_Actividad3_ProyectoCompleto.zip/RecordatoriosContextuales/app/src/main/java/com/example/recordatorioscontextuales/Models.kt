package com.example.recordatorioscontextuales

import java.time.LocalDateTime

sealed class Categoria(val etiqueta: String) {
    object Personal : Categoria("Personal")
    object Trabajo : Categoria("Trabajo")
    object Salud : Categoria("Salud")
    object Estudios : Categoria("Estudios")
}
sealed class Prioridad(val etiqueta: String, val nivel: Int) {
    object Baja : Prioridad("Baja", 1)
    object Media : Prioridad("Media", 2)
    object Alta : Prioridad("Alta", 3)
}
sealed class EstadoRecordatorio(val etiqueta: String) {
    object Pendiente : EstadoRecordatorio("Pendiente")
    object EnCurso : EstadoRecordatorio("En curso")
    object Completado : EstadoRecordatorio("Completado")
}
data class Ubicacion(
    val latitud: Double,
    val longitud: Double,
    val descripcion: String? = null
) {
    init {
        require(latitud in -90.0..90.0) { "Latitud inválida" }
        require(longitud in -180.0..180.0) { "Longitud inválida" }
    }
}
data class Recordatorio(
    val id: Int,
    val titulo: String,
    val descripcion: String,
    val categoria: Categoria,
    val prioridad: Prioridad,
    val estado: EstadoRecordatorio,
    val fechaVencimiento: LocalDateTime? = null,
    val ubicacion: Ubicacion? = null,
    val aviso: LocalDateTime? = null,
    val sincronizado: Boolean = false,
    val fechaCreacion: LocalDateTime = LocalDateTime.now(),
    val estadoSincronizacion: String = "Pendiente"
) {
    init {
        require(id > 0) { "El identificador debe ser positivo" }
        require(titulo.trim().length >= 4) { "El título debe tener al menos 4 caracteres" }
        require(descripcion.length <= 200) { "La descripción no puede superar 200 caracteres" }
        require(aviso == null || fechaVencimiento == null ||
            !aviso.isAfter(fechaVencimiento)) {
            "El aviso no puede ser posterior al vencimiento"
        }
    }
}
